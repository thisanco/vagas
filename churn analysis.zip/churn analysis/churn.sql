
/*
	https://stackoverflow.com/questions/28168055/convert-text-value-in-sql-server-from-utf8-to-iso-8859-1/31064459#31064459


CREATE FUNCTION dbo.UTF8_TO_NVARCHAR(@in VarChar(MAX))
   RETURNS NVarChar(MAX)
AS
BEGIN
   DECLARE @out NVarChar(MAX), @i int, @c int, @c2 int, @c3 int, @nc int

   SELECT @i = 1, @out = ''

   WHILE (@i <= Len(@in))
   BEGIN
      SET @c = Ascii(SubString(@in, @i, 1))

      IF (@c < 128)
      BEGIN
         SET @nc = @c
         SET @i = @i + 1
      END
      ELSE IF (@c > 191 AND @c < 224)
      BEGIN
         SET @c2 = Ascii(SubString(@in, @i + 1, 1))

         SET @nc = (((@c & 31) * 64 /* << 6 */) | (@c2 & 63))
         SET @i = @i + 2
      END
      ELSE
      BEGIN
         SET @c2 = Ascii(SubString(@in, @i + 1, 1))
         SET @c3 = Ascii(SubString(@in, @i + 2, 1))

         SET @nc = (((@c & 15) * 4096 /* << 12 */) | ((@c2 & 63) * 64 /* << 6 */) | (@c3 & 63))
         SET @i = @i + 3
      END

      SET @out = @out + NChar(@nc)
   END
   RETURN @out
END
GO
*/

/*
########################################################################################################################
A -CREATE TEMP TABLE TO ANALISYS DATA
########################################################################################################################

*/ 

--Imported data to pet'table

--validating table on my database
IF OBJECT_ID('tempdb..#analisys_churn') IS NOT NULL 
	DROP TABLE #analisys_churn

--validating table on my database
IF OBJECT_ID('tempdb..#analisys_churn') IS NULL 

	select * into #analisys_churn  from pet

/*
########################################################################################################################
B -let data standarlized 
########################################################################################################################

*/ 
	
	
update #analisys_churn  set created_at  = cast(DATEADD(DD,1,EOMONTH(created_at,-1)) as date)

alter table #analisys_churn alter column created_at date

update  #analisys_churn set updated_at  = cast(DATEADD(DD,1,EOMONTH(updated_at,-1)) as date)

update  #analisys_churn set deleted_at  = cast(DATEADD(DD,1,EOMONTH(deleted_at,-1)) as date)

alter table #analisys_churn alter column deleted_at date

update  #analisys_churn set deleted_at  = null where deleted_at = '1900-01-01'

update #analisys_churn  set all_revenue = replace(all_revenue,',','.')

alter table #analisys_churn alter column all_revenue numeric(18,2) 

update #analisys_churn set city = dbo.UTF8_TO_NVARCHAR(CITY)




-- Validate some data
--select COUNT(*),COUNT(DISTINCT ID) from #analisys_churn

--SELECT DISTINCT STATUS FROM #analisys_churn

--SELECT DISTINCT city FROM #analisys_churn


/*
########################################################################################################################
0 -Basics Analysis
########################################################################################################################

*/ 

--chart 1
select status,count(*) qty
from #analisys_churn
group by status
order by qty desc



-- chart 2
select 
status,
replace(v$,'.',',') v$
from (
select top 3 status, sum(all_revenue) v$
from #analisys_churn
group by status
order by v$ desc
) x


--chart 3
 
select CREATED_AT, count(*)from #analisys_churn
group by created_at



;with v_tab as (
select created_at,count(*) as qtd_mes 
from #analisys_churn
group by created_at
)

select *
,SUM(qtd_mes) OVER (order by created_at) acumulado 
from v_tab




--chart 4

;with v_tab as (

select created_at,SUM(all_revenue)  as total_month
from #analisys_churn
group by created_at
)

select *,
sum(total_month) over(order by created_at ) ac
from v_tab










/*
########################################################################################################################
1 -CHURN
########################################################################################################################

*/ 

drop table #new

drop table #deleted

drop table #cumulative_new

drop table #cumulative_deleted

drop table #churn_prep

select created_at,count(*) qty
into #new
from #analisys_churn
where status not in ('paused')
group by created_at

select   *, sum(qty)over(order by created_at) qty_cumulative
into #cumulative_new
from #new

select deleted_at,count(*) qty
into #deleted
from #analisys_churn
where status in ('canceled')
group by deleted_at
order by deleted_at


select   *, sum(qty)over(order by deleted_at) deleted_cumulative
into #cumulative_deleted
from #deleted
where deleted_at is not null


select 
created_at as data,
a.qty,
a.qty_cumulative,
a.qty_cumulative - isnull(b.deleted_cumulative,0) + isnull(b.qty,0)  as data_beggining_month,
a.qty_cumulative - isnull(b.deleted_cumulative,0)  as data_base_end_month,
b.qty cancelled
into #churn_prep
from #cumulative_new a
	left join #cumulative_deleted b
		on b.deleted_at =  a.created_at
order by a.created_at

-- chart 5
-- churn in the end of each year, except 2015 due to we don't have enough data for this year
select 
*,
replace(1 - cast(data_base_end_month as numeric(18,2))/cast(qty_cumulative as numeric(18,2)),'.',',')
from #churn_prep
where MONTH(data) = 12 and data not in ('2015-12-01')

-- churn per month/year
-- chart 6 to 10
select data,
replace(cast(isnull(cancelled,0) as numeric(18,2))/cast(data_beggining_month as numeric(18,2)),'.',',')
from #churn_prep



/*
########################################################################################################################
1.1 -COHORT
########################################################################################################################

*/

-- COHORT


select id,created_at,updated_at,deleted_at,cast(null as date) as data
into #summary
from #analisys_churn

create table #controle_data
(
controle_safra int
)

declare @min int ,@max int 

select @min = 1,@max = (SELECT COUNT(DISTINCT CREATED_AT) FROM #analisys_churn)

while @min<= @Max
	begin
		insert into #controle_data
		select @min
	
		select @min = @min + 1
	end

	
alter table #summary add meses_ativo int


update ex
set data = case when deleted_at is null then getdate() else deleted_at end
from #summary ex

	
update ex
set meses_ativo = DATEDIFF(MM,created_at,data)
from #summary ex



with cte as (
select created_at,COUNT(ID) qtd, 'M' + cast(CONTROLE_SAFRA as varchar(100)) AS CONTROLE_SAFRA
from #summary  a
	join #controle_data b	
		on a.meses_ativo >= controle_safra
where created_at BETWEEN '2016-01-01' AND '2016-12-31'
GROUP BY CONTROLE_SAFRA,created_at
)
select 
created_at,
[M1],
[M2],
[M3],
[M4],
[M5],
[M6],
[M7],
[M8],
[M9],
[M10],
[M11],
[M12],
[M13]
--INTO #REPORT_COHORT116
FROM CTE
PIVOT
(
	MAX(QTD) FOR CONTROLE_SAFRA IN ([M1],[M2],[M3],[M4],[M5],[M6],[M7],[M8],[M9],[M10],[M11],[M12],[M13])
) X 

-- chart 11 to 15
select * from #REPORT_COHORT116
order by 1 







/*
########################################################################################################################
1.2 -SEGMENTATION
########################################################################################################################

*/

-- SEGMENTATION


ALTER TABLE #analisys_churn ADD SEGMENTATION VARCHAR(100)



update #analisys_churn set SEGMENTATION = 'a' WHERE  average_ticket > 232.67


update #analisys_churn set SEGMENTATION = 'b' WHERE  average_ticket between 216.67 and  232.67


update #analisys_churn set SEGMENTATION = 'c' WHERE  average_ticket between 201.48  and  216.67


update #analisys_churn set SEGMENTATION = 'd' WHERE  average_ticket < 201.47



-- chart 16
SELECT SUM(ALL_REVENUE),SEGMENTATION
FROM #analisys_churn
GROUP BY SEGMENTATION
order by 1 desc


